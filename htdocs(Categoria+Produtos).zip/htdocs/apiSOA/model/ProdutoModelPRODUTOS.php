<?php

require_once './core/Conexao.php';


class ProdutoModel{

    public function SelectAll(){
        try {
            $pdo = Conexao::getInstance();
            
            $stmt = $pdo->prepare('SELECT * FROM produto ORDER BY id');
            $stmt->execute();

            return $stmt->fetchAll(PDO::FETCH_OBJ);
        } catch (\PDOException $e) {
            throw new \Exception(Exception::translateError($e->getMessage()));
        }catch(\Exception $e){
            throw new \Exception($e->getMessage());
        }

    }

    public function SelectId(int $id){
        try {
            $pdo = Conexao::getInstance();
            
            $stmt = $pdo->prepare('SELECT * FROM produto WHERE id = ?');
            $stmt->execute([$id]);

            return $stmt->fetchAll(PDO::FETCH_OBJ);
        } catch (\PDOException $e) {
            throw new \Exception(Exception::translateError($e->getMessage()));
        }catch(\Exception $e){
            throw new \Exception($e->getMessage());
        }
    }

    public function selectDescricao(String $descricao){
        try {
            $pdo = Conexao::getInstance();
            
            $stmt = $pdo->prepare('SELECT * FROM produto WHERE descricao = ?');
            $stmt->execute([$descricao]);

            return $stmt->fetchAll(PDO::FETCH_OBJ);
        } catch (\PDOException $e) {
            throw new \Exception(Exception::translateError($e->getMessage()));
        }catch(\Exception $e){
            throw new \Exception($e->getMessage());
        }
    }

    public function selectsku(int $sku){
        try {
            $pdo = Conexao::getInstance();
            
            $stmt = $pdo->prepare('SELECT * FROM produto WHERE sku = ?');
            $stmt->execute([$sku]);

            return $stmt->fetchAll(PDO::FETCH_OBJ);
        } catch (\PDOException $e) {
            throw new \Exception(Exception::translateError($e->getMessage()));
        }catch(\Exception $e){
            throw new \Exception($e->getMessage());
        }
    }

    public function insert(array $dados){
        
        try {
            $pdo = Conexao::getInstance();
            
            $sqlInsert = 'INSERT INTO produto(categoria_id, descricao, valor, sku) VALUES(?,?,?,?)';
            $stm = $pdo->prepare($sqlInsert);
            $stm->execute([$dados['categoria'],$dados['nome'],$dados['valor'],$dados['codigo']]);
            return ($stm->rowCount() > 0);

        } catch (\PDOException $e) {
            throw new \Exception(Exception::translateError($e->getMessage()));
        }catch(\Exception $e){
            throw new \Exception($e->getMessage());
        }
    }

    public function edit(array $dados){
        try {
            $pdo = Conexao::getInstance();
            $sqlUpdate = 'UPDATE produto SET descricao = ?, sku = ?, valor = ? , categoria_id = ? WHERE id= ?';
            $stm = $pdo->prepare($sqlUpdate);
            $stm ->execute([$dados ['descricao'],$dados ['sku'],$dados['valor'],$dados ['categoria_id'], $dados['id']]);
            $retorno = ($stm->rowCount() > 0);
            if ($retorno) {
                echo "Atualizado com sucesso";
            }else {
                echo "erro ao atualizar";
            }
            $retorno = ($stm->rowCount()>0);
            return $retorno;

        } catch (\PDOException $e) {
            throw new \Exception(Exception::translateError($e->getMessage()));
        }catch(\Exception $e){
            throw new \Exception($e->getMessage());
        }
    }
    

    public function delete(int $id){
        try {
            $pdo = Conexao::getInstance();
            
            $stmt = $pdo->prepare('DELETE FROM produto WHERE id = ?');
            $stmt->execute([$id]);

            return ($stmt->rowCount() > 0);
        } catch (\PDOException $e) {
            throw new \Exception(Exception::translateError($e->getMessage()));
        }catch(\Exception $e){
            throw new \Exception($e->getMessage());
        }
    }
}