<?php

require_once './model/CategoriaModel.php';

class CategoriaController{
    
    public function findAll(Request $request, Response $response, array $url){
        $produtoModel = new CategoriaModel();
        $response::json(['dados' => $produtoModel->SelectAll()],200);
    }

    public function find(Request $request, Response $response, array $url){
        $produtoModel = new CategoriaModel();
        $response::json(['dados' => $produtoModel->SelectId($url[0])],200);
    }

    public function addCategoria(Request $request, Response $response, array $url){
        $campos = $request->body();
        
        if ($campos['descricao'] == '') {
            $response::json(['status' => 'Informe o nome do produto'],406);
            exit;
        } 

        if ($campos['status'] == '') {
            $response::json(['status' => 'Informe a categoria do produto'],406);
            exit;
        }elseif (is_numeric($campos['status'])) {
            $response::json(['status' => 'A categoria deve ser informada em formato de texto'],406);
            exit;
        }
        if ($campos['status'] != 'ATIVO' && $campos['status'] != 'INATIVO') {
            $response::json(['status' => 'O valor do status é inválido'],406);
            exit;
        }

        $categoriaModel = new CategoriaModel();
        $categoria = $categoriaModel ->selectDescricao($campos['descricao']);

        if (!empty($categoria)) {
            $response::json(['status' => "Essa categoria ' " .$campos['descricao'] ." 'já existe!"],406);
            exit;
        }

        $retorno = $categoriaModel ->insert($campos);

        if ($retorno) {
            $response::json(['status' => 'Adicionado com sucesso'],201);
        }else{
            $response::json(['status' => 'Houve um erro ao inserir'],500);
        }

    }

    public function editCategoria(Request $request, Response $response, array $url){
        $campos = $request->body();
        $categoriaModel = new CategoriaModel();

        $retorno = $categoriaModel ->edit($campos);
        
        if ($campos['status'] != 'ATIVO' && $campos['status'] != 'INATIVO') {
            $response::json(['status' => 'O valor do status é inválido'],406);
            exit;
        }

        if ($retorno) {
            $response::json(['status' => 'Atualizado com sucesso'],201);
        }else{
            $response::json(['status' => 'Houve um erro ao atualizar'],500);
        }
        
        // $response::json(['status' => 'Editado com sucesso'],202);
    }

    public function deleteCategoria(Request $request, Response $response, array $url){
        $categoriaModel = new CategoriaModel();

        if (!is_numeric($url[0])) {
            $response::json(['status' => 'O ID deve ser um número inteiro válido'],406);
            exit;
        }
        $categoria = $categoriaModel->selectId($url[0]);
        if (empty($categoria)) {
            $response::json(['status' => 'Registro nao encontrado'],404);
            exit;
        }
        $retorno = $categoriaModel->delete($url[0]);
        if ($retorno) {
            $response::json(['status' => 'Deletado com sucesso'],202);
        }else{
            $response::json(['status' => 'Erro ao excluir'],500);
        }
    }
}