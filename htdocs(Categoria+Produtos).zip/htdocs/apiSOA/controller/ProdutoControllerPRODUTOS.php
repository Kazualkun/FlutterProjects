<?php

require_once './model/ProdutoModel.php';

class ProdutoController{
    
    public function findAll(Request $request, Response $response, array $url){
        $produtoModel = new ProdutoModel();
        $response::json(['dados' => $produtoModel->SelectAll()],200);
    }

    public function find(Request $request, Response $response, array $url){
        $produtoModel = new ProdutoModel();
        $response::json(['dados' => $produtoModel->SelectId($url[0])],200);
    }

    public function addProduto(Request $request, Response $response, array $url){
        $campos = $request->body();
        
        if ($campos['nome'] == '') {
            $response::json(['status' => 'Informe o nome do produto'],406);
            exit;
        } 

        if ($campos['categoria'] == '') {
            $response::json(['status' => 'Informe a categoria do produto'],406);
            exit;
        }elseif (!is_numeric($campos['categoria'])) {
            $response::json(['status' => 'A categoria deve ser um número inteiro válido'],406);
            exit;
        }

        if ($campos['codigo'] == '') {
            $response::json(['status' => 'Informe o codigo do produto'],406);
            exit;
        }

        if ($campos['valor'] == '') {
            $response::json(['status' => 'Informe o valor do produto'],406);
            exit;
        }

        $produtoModel = new ProdutoModel();
        $produto = $produtoModel ->selectDescricao($campos['nome']);
        $produto = $produtoModel ->selectsku($campos['codigo']);

        if (!empty($produto)) {
            $response::json(['status' => "Esse produto ' " .$campos['nome'] ." 'já existe!"],406);
            // exit;
            if (!empty($produto)) {
                $response::json(['status' => "Esse sku ' " .$campos['codigo'] ." 'já existe!"],406);
                exit;
            }
        }

        $retorno = $produtoModel ->insert($campos);

        if ($retorno) {
            $response::json(['status' => 'Adicionado com sucesso'],201);
        }else{
            $response::json(['status' => 'Houve um erro ao inserir'],500);
        }

    }

    public function editProduto(Request $request, Response $response, array $url){
        $campos = $request->body();
        $produtoModel = new ProdutoModel();

        $retorno = $produtoModel ->edit($campos);

        if ($retorno) {
            $response::json(['status' => 'Atualizado com sucesso'],201);
        }else{
            $response::json(['status' => 'Houve um erro ao atualizar'],500);
        }
        
        // $response::json(['status' => 'Editado com sucesso'],202);
    }

    public function deleteProduto(Request $request, Response $response, array $url){
        $produtoModel = new ProdutoModel();

        if (!is_numeric($url[0])) {
            $response::json(['status' => 'O ID deve ser um número inteiro válido'],406);
            exit;
        }
        $produto = $produtoModel->selectId($url[0]);
        if (empty($produto)) {
            $response::json(['status' => 'Registro nao encontrado'],404);
            exit;
        }
        $retorno = $produtoModel->delete($url[0]);
        if ($retorno) {
            $response::json(['status' => 'Deletado com sucesso'],202);
        }else{
            $response::json(['status' => 'Erro ao excluir'],500);
        }
    }
}