<?php

require_once 'Http.php';

Http::get('/categoria/find/{id}', 'CategoriaController@find');
Http::get('/categoria/findAll', 'CategoriaController@findAll');
Http::post('/categoria/add', 'CategoriaController@addCategoria');
Http::put('/categoria/edit', 'CategoriaController@editCategoria');
Http::delete('/categoria/delete/{id}', 'CategoriaController@deleteCategoria');
