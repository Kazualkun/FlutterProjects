<?php

require_once 'Http.php';

Http::get('/produto/find/{id}', 'ProdutoController@find');
Http::get('/produto/findAll', 'ProdutoController@findAll');
Http::post('/produto/add', 'ProdutoController@addProduto');
Http::put('/produto/edit', 'ProdutoController@editProduto');
Http::delete('/produto/delete/{id}', 'ProdutoController@deleteProduto');