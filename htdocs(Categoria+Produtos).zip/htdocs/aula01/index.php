<?php
define('HOST', 'localhost');
define('DBNAME', 'soa');
define('CHARSET', 'utf8');
define('USER', 'root');
define('PASSWORD', '');
define('PORTA_DB', '3306');

$opcoes = [\PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES UTF8'];
$pdo = new \PDO("mysql:host=" .HOST ."; dbname=" .DBNAME .";", USER, PASSWORD, $opcoes);

// var_dump($pdo);

// validação NOME Cliente
$sql = 'SELECT id FROM cliente WHERE nome = ?';
$stm = $pdo->prepare($sql);
$stm->execute(['Lucas']);
$cliente = $stm->fetch();

if (empty($cliente)) {
    $sqlInsert = 'INSERT INTO cliente(nome) VALUES(?)';
    $stm = $pdo->prepare($sqlInsert);
    $stm->execute(['lucas']);
    $retorno = ($stm->rowCount() > 0);
    if ($retorno) {
    echo "cliente inserido com sucesso";
    }else {
    echo "erro ao inserir cliente";
}
}else {
    echo 'Esse tipo já existe';
}

// validação NOME Cliente
$sql = 'SELECT id FROM cliente WHERE tipo_id = ? AND documento = ?';
$stm = $pdo->prepare($sql);
$stm->execute(['Lucas']);
$cliente = $stm->fetch();

if (empty($cliente)) {
    $sqlInsert = 'INSERT INTO cliente(nome) VALUES(?)';
    $stm = $pdo->prepare($sqlInsert);
    $stm->execute(['lucas']);
    $retorno = ($stm->rowCount() > 0);
    if ($retorno) {
    echo "cliente inserido com sucesso";
    }else {
    echo "erro ao inserir cliente";
}
}else {
    echo 'Esse tipo já existe';
}






//INSERT TIPO_PESSOA

//pessoa fisica
// $sql = 'SELECT descricao FROM tipo_pessoa WHERE descricao = ?';
// $stm = $pdo->prepare($sql);
// $stm->execute(['PF']);
// $tipo = $stm->fetch();

// if (empty($tipo)) {
// // //Insert
//     $sqlInsert = 'INSERT INTO tipo_pessoa(descricao) VALUES(?)';
//     $stm = $pdo->prepare($sqlInsert);
//     $stm->execute(['PF']);
//     $retorno = ($stm->rowCount() > 0);
//     if ($retorno) {
//     echo "inserido pessoa fisica com sucesso";
//     }else {
//     echo "erro ao inserir pessoa fisica";
// }
// }else {
//     echo 'Esse tipo já existe';
// }


// // validação pessoa juridica
// $sql = 'SELECT descricao FROM tipo_pessoa WHERE descricao = ?';
// $stm = $pdo->prepare($sql);
// $stm->execute(['PJ']);
// $tipo = $stm->fetch();

// if (empty($tipo)) {
// // //Insert
//     $sqlInsert = 'INSERT INTO tipo_pessoa(descricao) VALUES(?)';
//     $stm = $pdo->prepare($sqlInsert);
//     $stm->execute(['PJ']);
//     $retorno = ($stm->rowCount() > 0);
//     if ($retorno) {
//     echo "inserido pessoa jurídica com sucesso";
//     }else {
//     echo "erro ao inserir pessoa jurídica";
// }
// }else {
//     echo 'Esse tipo já existe';
// }

