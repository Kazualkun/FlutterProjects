<?php

$carro1 = [
    'modelo' => 'Grand Siena',
    'marca' => 'Fiat',
    'tipo' => 'Sedan',
    'placa' => '00000'
];

$carro2 = [
    'modelo' => 'KA',
    'marca' => 'Ford',
    'tipo' => 'hathc',
    'placa' => '00000'
];

$cadastro [] = $carro1;
$cadastro [] = $carro2;

if ($_SERVER['REQUEST_METHOD'] == "GET") {
    
    $modelo = isset($_GET['modelo']) ? $_GET ['modelo'] : '';
    $marca = isset($_GET['marca']) ? $_GET ['marca'] : '';

    if ($modelo == '') :
        echo "Informe o modelo";
        http_response_code(406);
        exit;
    endif;
    if ($modelo == '') :
        echo "Informe a marca";
        http_response_code(406);
        exit;
    endif;
    
    echo json_encode($cadastro);

}elseif ($_SERVER['REQUEST_METHOD'] == "POST") {

    $modelo = $_POST['modelo'];
    $marca = $_POST['marca'];
    $tipo = $_POST['tipo'];
    $placa = $_POST['placa'];

    echo "<br>-modelo: $modelo <br>-marca: $marca<br> -tipo: $tipo   <br>-placa: $placa";

}elseif ($_SERVER['REQUEST_METHOD'] == "PUT") {

    parse_str(file_get_contents('php://input'), $_PUT); 
    $modelo = $_PUT['modelo'];
    $marca = $_PUT['marca'];
    $tipo = $_PUT['tipo'];
    $placa = $_PUT['placa'];

    echo "<br>-modelo: $modelo <br>-marca: $marca<br> -tipo: $tipo   <br>-placa: $placa";
    

}elseif ($_SERVER['REQUEST_METHOD'] == "DELETE") {
// var_dump($_REQUEST);
$modelo = $_REQUEST['modelo'];
$placa = $_REQUEST['placa'];
echo "Meu modelo = $modelo <br> Minha placa = $placa ";
}

// {{ _.base_url }}/index2.php?modelo=FordKA&placa=1222 DELETE