<?php
// define('HOST', 'localhost');
// define('DBNAME', 'soa');
// define('CHARSET', 'utf8');
// define('USER', 'root');
// define('PASSWORD', '');
// define('PORTA_DB', '3306');

// $opcoes = [\PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES UTF8'];
// $pdo = new \PDO("mysql:host=" .HOST ."; dbname=" .DBNAME .";", USER, PASSWORD, $opcoes);

// var_dump($pdo);

// // Select
// $sql = 'SELECT * FROM produto';
// $stm = $pdo->prepare($sql);
// $stm->execute();
// $produtos = $stm->fetchAll();
// // var_dump($produtos);

// $sql = 'SELECT id FROM produto WHERE sku = ?';
// $stm = $pdo->prepare($sql);
// $stm->execute(['4566']);
// $produto = $stm->fetch();

// if (empty($produto)) {
// // //Insert
    // $sqlInsert = 'INSERT INTO produto(categoria_id, descricao, valor, sku) VALUES(?,?,?,?)';
    // $stm = $pdo->prepare($sqlInsert);
    // $stm->execute([1,"Produto de teste",110,'4566']);
    // $retorno = ($stm->rowCount() > 0);
//     if ($retorno) {
//     echo "inserido com sucesso";
//     }else {
//     echo "erro ao inserir";
// }
// }else {
//     echo 'Esse sku já existe 4566';
// }


// Update
// $sqlUpdate = 'UPDATE produto SET descricao = ? WHERE id = ?';
// $stm = $pdo->prepare($sqlUpdate);
// $stm ->execute(['COCA COLA EM LATA 350 ML', 1]);
// $retorno = ($stm->rowCount() > 0);
// if ($retorno) {
//     echo "Atualizado com sucesso";
// }else {
//     echo "erro ao atualizar";
// }

//Delete
// $sqlDelete = 'DELETE FROM produto WHERE id=?';
// $stm = $pdo->prepare($sqlDelete);
// $stm ->execute([1]);
// $retorno = ($stm->rowCount() > 0);
// if ($retorno) {
//     echo "Deletado com sucesso";
// }else {
//     echo "erro ao deletar";
// }

