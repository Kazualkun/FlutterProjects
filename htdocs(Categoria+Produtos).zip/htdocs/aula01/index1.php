<?php

$pessoa1 = [
    'nome' => 'Kauan',
    'idade' => 20,
    'salario' => 1984.99,
    'possui_faculdade' => false
];

$pessoa2 = [
    'nome' => 'Roberto',
    'idade' => 51,
    'salario' => 4999.99,
    'possui_faculdade' => true
];

$cadastro [] = $pessoa1;
$cadastro [] = $pessoa2;
//echo $cadastro;
if ($_SERVER['REQUEST_METHOD'] == "GET") {
    echo json_encode($cadastro);
}elseif ($_SERVER['REQUEST_METHOD'] == "POST") {
    // var_dump($_REQUEST);
    $primeiroNome = $_POST['nome'];
    $cidade = $_POST['cidade'];
    $sexo = $_POST['sexo'];

    echo "$primeiroNome, - $cidade, - $sexo";

}elseif ($_SERVER['REQUEST_METHOD'] == "PUT") {
// var_dump($_REQUEST);
parse_str(file_get_contents('php://input'), $_PUT); 
$primeiroNome = $_PUT['nome'];
    $cidade = $_PUT['cidade'];
    $sexo = $_PUT['sexo'];

    echo "$primeiroNome, - $cidade, - $sexo";
    

}elseif ($_SERVER['REQUEST_METHOD'] == "DELETE") {
// var_dump($_REQUEST);
$id = $_REQUEST['id'];
echo "Meu id = $id";
}
