import 'package:aula03/page1.dart';
import 'package:aula03/page3.dart';
import 'package:flutter/material.dart';

class Page2 extends StatefulWidget {
  const Page2({super.key});

  @override
  State<Page2> createState() => _Page2State();
}

class _Page2State extends State<Page2> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Page 2'),
        backgroundColor: Theme.of(context).primaryColor,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('Page 1'),
            ),
            ElevatedButton(
              onPressed: () async {
                bool? resposta = await Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const Page3(),
                  ),
                );

                if (resposta == null) return;

                if (resposta) {
                  print('Clicou em SIM');
                } else {
                  print('Clicou em NÂO');
                }
              },
              child: const Text('Page 3'),
            )
          ],
        ),
      ),
    );
  }
}
