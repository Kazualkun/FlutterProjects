import 'package:aula03/page1.dart';
import 'package:aula03/page2.dart';
import 'package:aula03/page4.dart';
import 'package:flutter/material.dart';

class Page3 extends StatefulWidget {
  const Page3({super.key});

  @override
  State<Page3> createState() => _Page3State();
}

class _Page3State extends State<Page3> {
  String mensagem = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Page 3'),
        backgroundColor: Theme.of(context).primaryColor,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('Page 2'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).popUntil((route) => route.isFirst);
              },
              child: const Text('Page 1'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context, true);
              },
              child: const Text('SIM'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context, false);
              },
              child: const Text('NÃO'),
            ),
            ElevatedButton(
              onPressed: () async {
                bool? resposta = await Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const Page4(),
                  ),
                );

                if (resposta == null) return;

                if (resposta) {
                  mensagem = 'Você clicou em SIM';
                } else {
                  mensagem = 'Você clicou em NÂO';
                }
                setState(() {});
              },
              child: const Text('Pergunta'),
            ),
            const SizedBox(
              height: 20,
            ),
            Text(
              mensagem,
              style: TextStyle(color: Colors.black, fontSize: 20),
            ),
          ],
        ),
      ),
    );
  }
}
