import 'package:aula03/page2.dart';
import 'package:flutter/material.dart';

class Page1 extends StatefulWidget {
  const Page1({super.key});

  @override
  State<Page1> createState() => _Page1State();
}

class _Page1State extends State<Page1> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Page 1'),
        backgroundColor: Theme.of(context).primaryColor,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  // Navega para a segunda página caso a validação seja bem-sucedida.
                  context,
                  MaterialPageRoute(
                    builder: (context) => const Page2(),
                  ), // Cria a rota para a segunda página.
                );
              },
              child: const Text('Page 2'),
            )
          ],
        ),
      ),
    );
  }
}
