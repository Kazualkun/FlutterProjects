import 'package:flutter/material.dart';
import 'package:aula04/terceira_page.dart';

class TerceiraPage extends StatefulWidget {
  const TerceiraPage({
    super.key,
    required this.umParametro,
    required this.doisParametro,
    required this.tresParametro,
  });

  final String umParametro;
  final String doisParametro;
  final String tresParametro;

  @override
  State<TerceiraPage> createState() => _TerceiraPageState();
}

class _TerceiraPageState extends State<TerceiraPage> {
  final _formKey = GlobalKey<FormState>();
  final _savedValue1 = TextEditingController();
  final _savedValue2 = TextEditingController();
  final _savedValue3 = TextEditingController();

  @override
  void initState() {
    super.initState();

    _savedValue1.text = widget.umParametro;
    _savedValue2.text = widget.doisParametro;
    _savedValue3.text = widget.tresParametro;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Pagina 03'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              TextFormField(
                controller: _savedValue1,
                onChanged: (value) {
                  print('Campo 1 - onChanged: $value');
                },
                onFieldSubmitted: (value) {
                  print('Campo 1 - onFieldSubmitted: $value');
                },
                onEditingComplete: () {
                  print('Campo 1 - onEditingComplete');
                  FocusScope.of(context).nextFocus();
                },
                validator: (value) {
                  print('Campo 1 - validator: $value');
                  if (value == null || value.isEmpty) {
                    return 'Campo 1 obrigatório';
                  }
                  return null;
                },
                onSaved: (value) {
                  print('Campo 1 - onSaved: $value');
                  _savedValue1.text = value!;
                },
                onTap: () {
                  print('Campo 1 - onTap');
                },
              ),
              const SizedBox(height: 50),
              TextFormField(
                controller: _savedValue2,
                onChanged: (value) {
                  print('Campo 2 - onChanged: $value');
                },
                onFieldSubmitted: (value) {
                  print('Campo 2 - onFieldSubmitted: $value');
                },
                onEditingComplete: () {
                  print('Campo 2 - onEditingComplete');
                  FocusScope.of(context).nextFocus();
                },
                validator: (value) {
                  print('Campo 2 - validator: $value');
                  if (value == null || value.isEmpty) {
                    return 'Campo 2 obrigatório';
                  }
                  return null;
                },
                onSaved: (value) {
                  print('Campo 2 - onSaved: $value');
                  _savedValue2.text = value!;
                },
                onTap: () {
                  print('Campo 2 - onTap');
                },
              ),
              const SizedBox(height: 50),
              TextFormField(
                controller: _savedValue3,
                onChanged: (value) {
                  print('Campo 3 - onChanged: $value');
                },
                onFieldSubmitted: (value) {
                  print('Campo 3 - onFieldSubmitted: $value');
                },
                onEditingComplete: () {
                  print('Campo 3 - onEditingComplete');
                  FocusScope.of(context).nextFocus();
                },
                validator: (value) {
                  print('Campo 3 - validator: $value');
                  if (value == null || value.isEmpty) {
                    return 'Campo 3 obrigatório';
                  }
                  return null;
                },
                onSaved: (value) {
                  print('Campo 3 - onSaved: $value');
                  _savedValue3.text = value!;
                },
                onTap: () {
                  print('Campo 3 - onTap');
                },
              ),
              const SizedBox(height: 40),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  ElevatedButton(
                    onPressed: () {
                      _formKey.currentState!.reset();
                      print('onReset: Formulário resetado');
                    },
                    child: Text(
                      'Resetar',
                      style: TextStyle(
                        color: Colors.grey,
                      ),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      side: BorderSide(
                          color: const Color.fromARGB(255, 173, 173, 173),
                          width: 1),
                    ),
                  ),
                  const SizedBox(
                    width: 20,
                  ),
                  ElevatedButton(
                    onPressed: () {
                      if (_formKey.currentState!.validate()) {
                        _formKey.currentState!.save();
                        print(
                            'Formulário válido. Valores salvos: $_savedValue1, $_savedValue2');
                      }
                    },
                    child: Text('Salvar'),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
