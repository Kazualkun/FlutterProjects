import 'package:flutter/material.dart';
import 'package:aula04/segunda_page.dart'; // Importa a segunda página que será navegada após validação.

void main() {
  runApp(
      const MyApp()); // Função principal que inicia o aplicativo, chamando o widget MyApp.
}

class MyApp extends StatelessWidget {
  const MyApp({super.key}); // Construtor padrão do MyApp.

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner:
          false, // Remove o banner de "Debug" do canto superior direito.
      title: 'Flutter Demo', // Define o título do aplicativo.
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
            seedColor: const Color.fromARGB(255, 208, 42,
                42)), // Define o tema de cores usando uma semente de cor.
        useMaterial3: true, // Habilita o uso do Material 3 no tema.
      ),
      home: const MyHomePage(
          title: 'Flutter Demo Home Page'), // Define a página inicial do app.
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage(
      {super.key,
      required this.title}); // Construtor padrão que recebe o título.
  final String title; // Variável para armazenar o título da página.

  @override
  State<MyHomePage> createState() =>
      _MyHomePageState(); // Cria o estado associado ao widget.
}

class _MyHomePageState extends State<MyHomePage> {
  String _email =
      ''; // Variável para armazenar o texto digitado no campo de email.
  String _senha =
      ''; // Variável para armazenar o texto digitado no campo de senha.
  String _mensagem = 'Você ainda não logou'; // Mensagem exibida na tela.

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromARGB(7, 255, 255, 255),
      body: SingleChildScrollView(
        // Permite rolagem quando o teclado aparece ou conteúdo é extenso.
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(
                15.0), // Define um padding de 15 pixels ao redor do conteúdo.
            child: Column(
              mainAxisAlignment: MainAxisAlignment
                  .center, // Centraliza verticalmente o conteúdo.
              children: <Widget>[
                const SizedBox(
                  height: 100, // Espaçamento vertical entre os widgets.
                ),
                CircleAvatar(
                  radius:
                      50, // Define o tamanho do CircleAvatar (diâmetro de 100)
                  backgroundColor: Colors
                      .transparent, // Define a cor de fundo como transparente (opcional)
                  child: ClipOval(
                    child: Image.network(
                      'https://bkpsitecpsnew.blob.core.windows.net/uploadsitecps/sites/1/2022/08/cps-logo-identidade.jpg',
                      fit: BoxFit
                          .cover, // Ajusta a imagem para cobrir toda a área circular
                      width: 100, // Define a largura da imagem
                      height: 100, // Define a altura da imagem
                    ),
                  ),
                ),
                const SizedBox(
                  height: 50, // Espaçamento vertical entre os widgets.
                ),
                TextField(
                  onChanged: (textoDigitado) {
                    _email =
                        textoDigitado; // Atualiza a variável _email conforme o usuário digita.
                    setState(
                        () {}); // Atualiza a interface para refletir as mudanças.
                  },
                  keyboardType:
                      TextInputType.text, // Define o tipo de teclado (texto).
                  style: TextStyle(
                      color: Theme.of(context)
                          .primaryColor, // Define a cor do texto digitado.
                      fontSize: 30,
                      fontWeight: FontWeight.bold),
                  decoration: InputDecoration(
                    filled: true, // Preenche o fundo do campo de texto.
                    fillColor: const Color.fromARGB(35, 255, 255,
                        255), // Define a cor de fundo do campo de texto.
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(
                          20), // Define bordas arredondadas.
                      borderSide: const BorderSide(
                          color: Colors.white), // Cor da borda.
                    ),
                    labelText: 'Informe seu e-mail', // Texto do rótulo.
                    helperText:
                        'Não esqueça do @', // Texto de ajuda abaixo do campo.
                    helperStyle: const TextStyle(
                      color: Colors.red,
                      fontSize: 15,
                    ),
                    labelStyle: const TextStyle(
                      color: Colors.red, // Cor do texto do rótulo.
                      fontSize: 20,
                    ),
                  ),
                ),
                const SizedBox(
                  height: 50, // Espaçamento vertical entre os widgets.
                ),
                TextField(
                  onChanged: (textoDigitado) {
                    _senha =
                        textoDigitado; // Atualiza a variável _senha conforme o usuário digita.
                    setState(
                        () {}); // Atualiza a interface para refletir as mudanças.
                  },
                  obscureText: true, // Oculta o texto digitado (para senhas).
                  keyboardType:
                      TextInputType.text, // Define o tipo de teclado (texto).
                  style: TextStyle(
                      color: Theme.of(context)
                          .primaryColor, // Define a cor do texto digitado.
                      fontSize: 30,
                      fontWeight: FontWeight.bold),
                  decoration: InputDecoration(
                    filled: true, // Preenche o fundo do campo de texto.
                    fillColor: const Color.fromARGB(35, 255, 255,
                        255), // Define a cor de fundo do campo de texto.
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(
                          20), // Define bordas arredondadas.
                      borderSide: const BorderSide(
                          color: Colors.white), // Cor da borda.
                    ),
                    labelText: 'Informe sua senha', // Texto do rótulo.
                    helperText:
                        'Não esqueça a senha', // Texto de ajuda abaixo do campo.
                    helperStyle: const TextStyle(
                      color: Colors.red,
                      fontSize: 15,
                    ),
                    labelStyle: const TextStyle(
                      color: Colors.red, // Cor do texto do rótulo.
                      fontSize: 20,
                    ),
                  ),
                ),
                const SizedBox(
                  height: 50, // Espaçamento vertical entre os widgets.
                ),
                ElevatedButton(
                  onPressed: () {
                    if (_email == 'adm' && _senha == '123') {
                      // Valida se as credenciais estão corretas.
                      Navigator.push(
                        // Navega para a segunda página caso a validação seja bem-sucedida.
                        context,
                        MaterialPageRoute(
                          builder: (context) => SegundaPage(
                            meuParametro: 'texto enviado',
                            segundoParametro: 'email@email.com',
                            terceiroParametro: _senha,
                          ),
                        ), // Cria a rota para a segunda página.
                      );
                    } else {
                      _mensagem =
                          'Usuario Inválido'; // Atualiza a mensagem em caso de falha na validação.
                    }
                    setState(
                        () {}); // Atualiza a interface para refletir a nova mensagem.
                  },
                  child: const Text('Validar'), // Texto exibido no botão.
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
