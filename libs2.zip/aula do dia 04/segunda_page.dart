// Importa os pacotes necessários para criar a interface do usuário no Flutter.
import 'package:aula04/terceira_page.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

// Define uma classe StatefulWidget chamada SegundaPage, que será a segunda página da aplicação.
class SegundaPage extends StatefulWidget {
  // Construtor da classe SegundaPage.
  const SegundaPage(
      {super.key,
      required this.meuParametro,
      required this.segundoParametro,
      required this.terceiroParametro});

  final String meuParametro;
  final String segundoParametro;
  final String terceiroParametro;

  // Cria o estado associado à SegundaPage.
  @override
  State<SegundaPage> createState() => _SegundaPageState();
}

// Classe responsável por gerenciar o estado da SegundaPage.
class _SegundaPageState extends State<SegundaPage> {
  // Cria uma chave global para o formulário, usada para identificar o formulário e validar seus campos.
  final _formkey = GlobalKey<FormState>();
  // Controladores para manipular os dados dos campos de texto (nome, email e senha).
  final _inputNome = TextEditingController();
  final _inputEmail = TextEditingController();
  final _inputSenha = TextEditingController();

  @override
  void initState() {
    super.initState();

    _inputNome.text = widget.meuParametro;
    _inputEmail.text = widget.segundoParametro;
    _inputSenha.text = widget.terceiroParametro;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // AppBar é a barra de título da página.
      appBar: AppBar(
        title: const Text('Segunda-feira'), // Título exibido na barra de app.
      ),
      // SingleChildScrollView permite a rolagem da página caso o conteúdo seja maior que a tela.
      body: SingleChildScrollView(
        child: Center(
          // Padding para adicionar espaçamento ao redor do conteúdo.
          child: Padding(
            padding: const EdgeInsets.all(15.0),
            // Form widget que agrupa e gerencia os campos de entrada de dados.
            child: Form(
              key: _formkey, // Associa o formulário à chave global.
              child: Column(
                mainAxisAlignment: MainAxisAlignment
                    .center, // Centraliza os widgets verticalmente.
                children: <Widget>[
                  // Campo de texto para o nome do usuário.
                  TextFormField(
                    controller:
                        _inputNome, // Controlador associado ao campo de nome.
                    // Validação do campo de nome.
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Preencha seu nome'; // Mensagem de erro se o campo estiver vazio.
                      }

                      if (value.length < 5) {
                        return 'Seu nome precisa ter mais de 5 caracteres'; // Mensagem de erro se o nome for muito curto.
                      }
                    },
                    keyboardType: TextInputType
                        .text, // Define o tipo de teclado (texto normal).
                    style: TextStyle(
                        color: Theme.of(context).primaryColor,
                        fontSize: 30,
                        fontWeight: FontWeight.bold),
                    // Decoração do campo de texto, incluindo bordas, rótulo e cor de fundo.
                    decoration: InputDecoration(
                      filled: true,
                      fillColor: Colors.grey,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20),
                        borderSide: const BorderSide(color: Colors.green),
                      ),
                      labelText:
                          'Informe seu nome', // Texto de rótulo do campo.
                      helperStyle: const TextStyle(
                        color: Colors.red,
                        fontSize: 15,
                      ),
                      labelStyle: const TextStyle(
                        color: Colors.amber,
                        fontSize: 20,
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 50,
                  ),
                  // Campo de texto para o email do usuário.
                  TextFormField(
                    controller:
                        _inputEmail, // Controlador associado ao campo de email.
                    // Validação do campo de email.
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Informe seu e-mail'; // Mensagem de erro se o campo estiver vazio.
                      }

                      if (!value.contains('@')) {
                        return 'Seu e-mail é inválido'; // Mensagem de erro se o email for inválido.
                      }
                    },
                    keyboardType: TextInputType
                        .text, // Define o tipo de teclado (texto normal).
                    style: TextStyle(
                        color: Theme.of(context).primaryColor,
                        fontSize: 30,
                        fontWeight: FontWeight.bold),
                    // Decoração do campo de texto, incluindo bordas, rótulo e cor de fundo.
                    decoration: InputDecoration(
                      filled: true,
                      fillColor: Colors.grey,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20),
                        borderSide: const BorderSide(color: Colors.green),
                      ),
                      labelText:
                          'Informe seu e-mail', // Texto de rótulo do campo.
                      helperStyle: const TextStyle(
                        color: Colors.red,
                        fontSize: 15,
                      ),
                      labelStyle: const TextStyle(
                        color: Colors.amber,
                        fontSize: 20,
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 50,
                  ),
                  // Campo de texto para a senha do usuário.
                  TextFormField(
                    controller:
                        _inputSenha, // Controlador associado ao campo de senha.
                    // Validação do campo de senha.
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Informe sua senha'; // Mensagem de erro se o campo estiver vazio.
                      }

                      if (value.length < 3) {
                        return 'Sua senha é muito curta'; // Mensagem de erro se a senha for curta.
                      }
                    },
                    obscureText:
                        false, // Oculta o texto digitado (para senhas).
                    keyboardType: TextInputType
                        .text, // Define o tipo de teclado (texto normal).
                    style: TextStyle(
                        color: Theme.of(context).primaryColor,
                        fontSize: 30,
                        fontWeight: FontWeight.bold),
                    // Decoração do campo de texto, incluindo bordas, rótulo e cor de fundo.
                    decoration: InputDecoration(
                      filled: true,
                      fillColor: Colors.grey,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20),
                        borderSide: const BorderSide(color: Colors.green),
                      ),
                      labelText:
                          'Informe sua senha', // Texto de rótulo do campo.
                      helperStyle: const TextStyle(
                        color: Colors.red,
                        fontSize: 15,
                      ),
                      labelStyle: const TextStyle(
                        color: Colors.amber,
                        fontSize: 20,
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 50,
                  ),
                  // Botão de enviar os dados do formulário.
                  ElevatedButton(
                    onPressed: () {
                      // Quando o botão é pressionado, verifica se o formulário é válido.
                      setState(
                        () {
                          if (_formkey.currentState!.validate()) {
                            // Se o formulário for válido, imprime as informações nos campos de texto.
                            print('Gravado com sucesso !');
                            print('Seu nome é ${_inputNome.text}');
                            print('Seu e-mail é ${_inputEmail.text}');
                            print('Sua senha é ${_inputSenha.text}');
                          }
                        },
                      );
                    },
                    child: Text('Gravar Dados'), // Texto do botão.
                  ),
                  // Exibe o nome digitado no campo de nome.
                  Text(
                    _inputNome.text,
                  ),
                  // Exibe o email digitado no campo de email.
                  Text(
                    _inputEmail.text,
                  ),
                  // Exibe a senha digitada no campo de senha.
                  Text(
                    _inputSenha.text,
                  ),
                  const SizedBox(
                    height: 50, // Espaçamento vertical entre os widgets.
                  ),
                  ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                        // Navega para a segunda página caso a validação seja bem-sucedida.
                        context,
                        MaterialPageRoute(
                          builder: (context) => TerceiraPage(
                            umParametro: _inputNome.text,
                            doisParametro: _inputEmail.text,
                            tresParametro: _inputSenha.text,
                          ),
                        ), // Cria a rota para a segunda página.
                      );
                    },
                    child: const Text(
                        'Terceira Pagina'), // Texto exibido no botão.
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
