import 'package:flutter/material.dart';

class ThirdPage extends StatelessWidget {
  final String username;
  final String password;
  final String additionalInfo;

  const ThirdPage({
    super.key,
    required this.username,
    required this.password,
    required this.additionalInfo,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Third Page'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('Username: $username', style: const TextStyle(fontSize: 18)),
            const SizedBox(height: 16),
            Text('Password: $password', style: const TextStyle(fontSize: 18)),
            const SizedBox(height: 16),
            Text('Additional Information: $additionalInfo', style: const TextStyle(fontSize: 18)),
            const SizedBox(height: 32),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('Go Back'),
            ),
          ],
        ),
      ),
    );
  }
}
