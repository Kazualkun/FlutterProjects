import 'package:flutter/material.dart';

class FourthPage extends StatelessWidget {
  FourthPage({super.key});

  // Controllers e ValueNotifiers
  final TextEditingController textField1Controller = TextEditingController();
  final TextEditingController textField2Controller = TextEditingController();
  final TextEditingController textFormField1Controller = TextEditingController();
  final TextEditingController textFormField2Controller = TextEditingController();

  final ValueNotifier<bool> switchContainer1 = ValueNotifier<bool>(false);
  final ValueNotifier<bool> switchContainer2 = ValueNotifier<bool>(false);

  // ValueNotifiers para cor dos containers
  final ValueNotifier<Color> container1Color = ValueNotifier<Color>(Colors.grey);
  final ValueNotifier<Color> container2Color = ValueNotifier<Color>(Colors.brown);

  final ValueNotifier<bool> changeTextSize = ValueNotifier<bool>(false);
  final ValueNotifier<bool> showSpecialMessage = ValueNotifier<bool>(false);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Fourth Page'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // Linha com os TextField e os Containers controlados por Switches
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Flexible(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      TextField(
                        controller: textField1Controller,
                        decoration: const InputDecoration(
                          labelText: 'TextField 1',
                          border: OutlineInputBorder(),
                        ),
                      ),
                      const SizedBox(height: 16),
                      TextField(
                        controller: textField2Controller,
                        decoration: const InputDecoration(
                          labelText: 'TextField 2',
                          border: OutlineInputBorder(),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 16),
                Column(
                  children: [
                    ValueListenableBuilder<Color>(
                      valueListenable: container1Color,
                      builder: (context, color, child) {
                        return Container(
                          width: 100,
                          height: 100,
                          color: color,
                        );
                      },
                    ),
                    const SizedBox(height: 16),
                    ValueListenableBuilder<Color>(
                      valueListenable: container2Color,
                      builder: (context, color, child) {
                        return Container(
                          width: 100,
                          height: 100,
                          color: color,
                        );
                      },
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 32),

            // Form Fields
            TextFormField(
              controller: textFormField1Controller,
              decoration: const InputDecoration(
                labelText: 'TextFormField 1',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: textFormField2Controller,
              decoration: const InputDecoration(
                labelText: 'TextFormField 2',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 32),

            // Switches para Containers
            ValueListenableBuilder<bool>(
              valueListenable: switchContainer1,
              builder: (context, value, child) {
                return SwitchListTile(
                  title: const Text('Alterar cor do Container 1'),
                  value: value,
                  onChanged: (bool newValue) {
                    switchContainer1.value = newValue;
                    container1Color.value = newValue ? Colors.green : Colors.grey;
                  },
                );
              },
            ),
            ValueListenableBuilder<bool>(
              valueListenable: switchContainer2,
              builder: (context, value, child) {
                return SwitchListTile(
                  title: const Text('Alterar cor do Container 2'),
                  value: value,
                  onChanged: (bool newValue) {
                    switchContainer2.value = newValue;
                    container2Color.value = newValue ? Colors.blue : Colors.brown;
                  },
                );
              },
            ),
            const SizedBox(height: 32),

            // Botões que controlam outros aspectos
            ElevatedButton(
              onPressed: () {
                changeTextSize.value = !changeTextSize.value;
              },
              child: const Text('Alterar Tamanho do Texto'),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                showSpecialMessage.value = !showSpecialMessage.value;
              },
              child: const Text('Mostrar Mensagem Especial'),
            ),
            const SizedBox(height: 32),

            // Texto controlado pelo botão
            ValueListenableBuilder<bool>(
              valueListenable: changeTextSize,
              builder: (context, isLarge, child) {
                return Text(
                  'Texto com Tamanho Controlável',
                  style: TextStyle(
                    fontSize: isLarge ? 24 : 16,
                    fontWeight: FontWeight.bold,
                  ),
                );
              },
            ),
            const SizedBox(height: 16),

            // Mensagem especial controlada pelo botão
            ValueListenableBuilder<bool>(
              valueListenable: showSpecialMessage,
              builder: (context, show, child) {
                return Visibility(
                  visible: show,
                  child: Container(
                    padding: const EdgeInsets.all(16.0),
                    decoration: BoxDecoration(
                      color: Colors.amber,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Text(
                      'Mensagem Especial Ativada!',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500),
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
