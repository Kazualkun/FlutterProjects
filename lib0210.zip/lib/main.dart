import 'package:estudos/fourth_page.dart';
import 'package:flutter/material.dart';
import 'second_page.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(useMaterial3: true),
      home: FourthPage(),
    );
  }
}

class LoginPage extends StatelessWidget {
  const LoginPage({super.key});

  @override
  Widget build(BuildContext context) {
    final usernameController = TextEditingController();
    final passwordController = TextEditingController();
    final ValueNotifier<bool> isDarkTheme = ValueNotifier<bool>(false);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Login Page'),
      ),
      body: ValueListenableBuilder<bool>(
        valueListenable: isDarkTheme,
        builder: (context, isDark, child) {
          return Container(
            color: isDark ? Colors.blueGrey : Colors.white,
            padding: const EdgeInsets.all(16.0),
            child: Form(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  TextFormField(
                    controller: usernameController,
                    decoration: const InputDecoration(labelText: 'Username'),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter your username';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: passwordController,
                    decoration: const InputDecoration(labelText: 'Password'),
                    obscureText: true,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter your password';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 32),
                  ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => SecondPage(
                            username: usernameController.text,
                            password: passwordController.text,
                          ),
                        ),
                      );
                    },
                    child: const Text('Go to Second Page'),
                  ),
                  const SizedBox(height: 20),
                  SwitchListTile(
                    title: const Text('Dark Theme'),
                    value: isDarkTheme.value,
                    onChanged: (bool value) {
                      isDarkTheme.value = value;
                    },
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
