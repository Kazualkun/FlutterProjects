import 'package:flutter/material.dart';
import 'third_page.dart';

class SecondPage extends StatelessWidget {
  final String username;
  final String password;

  SecondPage({super.key, required this.username, required this.password});

  final ValueNotifier<bool> showUsername = ValueNotifier<bool>(false);
  final ValueNotifier<bool> showPassword = ValueNotifier<bool>(false);
  final TextEditingController thirdFieldController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Second Page'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ValueListenableBuilder<bool>(
              valueListenable: showUsername,
              builder: (context, show, child) {
                return Visibility(
                  visible: show,
                  child: Text('Username: $username', style: const TextStyle(fontSize: 18)),
                );
              },
            ),
            const SizedBox(height: 16),
            ValueListenableBuilder<bool>(
              valueListenable: showPassword,
              builder: (context, show, child) {
                return Visibility(
                  visible: show,
                  child: Text('Password: $password', style: const TextStyle(fontSize: 18)),
                );
              },
            ),
            const SizedBox(height: 32),
            TextFormField(
              controller: thirdFieldController,
              decoration: const InputDecoration(labelText: 'Additional Information'),
            ),
            const SizedBox(height: 16),
            SwitchListTile(
              title: const Text('Show Username'),
              value: showUsername.value,
              onChanged: (bool value) {
                showUsername.value = value;
              },
            ),
            SwitchListTile(
              title: const Text('Show Password'),
              value: showPassword.value,
              onChanged: (bool value) {
                showPassword.value = value;
              },
            ),
            const SizedBox(height: 32),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ThirdPage(
                      username: username,
                      password: password,
                      additionalInfo: thirdFieldController.text,
                    ),
                  ),
                );
              },
              child: const Text('Go to Third Page'),
            ),
          ],
        ),
      ),
    );
  }
}
